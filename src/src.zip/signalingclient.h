#ifndef SIGNALINGCLIENT_H
#define SIGNALINGCLIENT_H

#include "SocketIO/sio_client.h"
#include <string>
#include <functional>

class SignalingClient {
public:
    SignalingClient(const std::string& serverUrl);
    ~SignalingClient();

    void connect(const std::string& serverUrl);
    void disconnect();

    void sendSDP(const std::string& sdp, bool isOffer);
    void sendICECandidate(const std::string& candidate);

    void setOnSDPReceived(std::function<void(const std::string&, bool)> handler);
    void setOnICECandidateReceived(std::function<void(const std::string&)> handler);

private:
    sio::client socket_;
    std::function<void(const std::string&, bool)> onSDPReceived_;
    std::function<void(const std::string&)> onICECandidateReceived_;

    void setupEventHandlers();
};

#endif // SIGNALINGCLIENT_H
